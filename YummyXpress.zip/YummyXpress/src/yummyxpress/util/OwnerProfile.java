/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yummyxpress.util;

/**
 *
 * @author 91999
 */
public class OwnerProfile {

    public static String getOwnerName() {
        return ownerName;
    }

    public static void setOwnerName(String ownerName) {
        OwnerProfile.ownerName = ownerName;
    }

    public static String getCompanyId() {
        return companyId;
    }

    public static void setCompanyId(String companyId) {
        OwnerProfile.companyId = companyId;
    }

    public static String getCompanyname() {
        return companyname;
    }

    public static void setCompanyname(String companyname) {
        OwnerProfile.companyname = companyname;
    }
    private static String ownerName;
    private static String companyId;
    private static String companyname;
}
